                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1819242
Origami Carabiner by ddf3d.com by Charlie1982 is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

Announce ORIGAMI Carabiner !
---------------------------------------------------
This is the design based on "selflex level 7" customized to special size.
Perfectly hook on your back pack or key for your daily life.
The design is simplified and strong, print without support and raft in short time.

**Layer Texture design**
Customized your own texture by different layer height.
For bring tactile and visual new feelings.

The design come with only 2 parts, hook and door, very easy to assembly and easy to make different scale for your need.

Door Flexible Strength = 7 (check out the selflex introduce on http://www.ddf3d.com/design)

Download more cool design:
http://www.ddf3d.com/goods

Visit our website:
http://www.ddf3d.com/

Design for general FDM 3D printer print by PLA or ABS material.
No additional support need, easy to print.
Fast print design make general print time around 45-100 min.

When print on scale 1, infill 50%, nozzle 0.4mm, shell loop 3, general can load 15-35kg load.
The design can print without support and raft set.
Layer high from 0.15mm~0.3mm is fine.
Infill better to use over 50%.

cheers ;)

ddf3d.com
 

# Print Settings

Printer: PING 3D Printer
Rafts: Doesn't Matter
Supports: No
Resolution: 0.2mm
Infill: 50%

Notes: 
After stress tested, as our test, the number of loops is more important than infill, general nozzle is 0.4mm, put number of loops more than general 2 loops, change to 3 or more, this will make solid shape of the hook part, also bring stronger strengh of door part :)

Design for general FDM 3D printer print by PLA or ABS material.
When print on scale 1, infill 50%, nozzle 0.4mm, shell loop 3, general can load 15-35kg load.
 
ABS is better than PLA on tensile load and flexible spring strength.

# How I Designed This

<iframe src="//www.youtube.com/embed/SRAUg5wER9U" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/QsJYL46oCqQ" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/-GuSk6V4ZcY" frameborder="0" allowfullscreen></iframe>

# Special Reward to Supporter

![Alt text](https://cdn.thingiverse.com/assets/29/cd/03/0e/c7/_DSC00927_TG_S.jpg)

Special Reward to Supporter
-------------------------------------------------
TIP us $5 and reward the "Classic Lock Carabiner" 3d printable file.
**We welcome your support by simple Tip to us, and we'll reward the "Classic Lock Carabiner" 3d printable file to you.**
If you are going to Tip us and get reward, please follow the step.
1) Tip us on Thingiverse $5 or more.
2) Send us a message on "ddf3d.com" contact, tell us your mail and thingiverse ID.
3) Receive the mail attachment the reward 3d file.
Please Note: Please understand, we will send the file manualy ASAP, if you don't receive the mail in 12hrs, please contact us again. Thank you

<iframe src="//www.youtube.com/embed/W4e2gUbTutk" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/L2Kzo_WZv-g" frameborder="0" allowfullscreen></iframe>